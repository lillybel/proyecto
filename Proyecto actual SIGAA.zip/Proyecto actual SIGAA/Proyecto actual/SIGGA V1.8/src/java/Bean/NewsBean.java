
package Bean;


public class NewsBean {
    
}
