
package DaoConexion;

public class NewsDao {
    
}
