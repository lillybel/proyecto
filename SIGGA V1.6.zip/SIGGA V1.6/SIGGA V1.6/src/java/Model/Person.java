/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Estudiante
 */
public class Person {
    private int IdPerson;
    private String NamePerson;
    private  int Password;
    private String Email;
    private State IdState;

    public Person(int IdPerson, String NamePerson, int Password, String Email, State IdState) {
        this.IdPerson = IdPerson;
        this.NamePerson = NamePerson;
        this.Password = Password;
        this.Email = Email;
        this.IdState = IdState;
    }

    public Person() {
    }

    public int getIdPerson() {
        return IdPerson;
    }

    public void setIdPerson(int IdPerson) {
        this.IdPerson = IdPerson;
    }

    public String getNamePerson() {
        return NamePerson;
    }

    public void setNamePerson(String NamePerson) {
        this.NamePerson = NamePerson;
    }

    public int getPassword() {
        return Password;
    }

    public void setPassword(int Password) {
        this.Password = Password;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public State getIdState() {
        return IdState;
    }

    public void setIdState(State IdState) {
        this.IdState = IdState;
    }

    
}