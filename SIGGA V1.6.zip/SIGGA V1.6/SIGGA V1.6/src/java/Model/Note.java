/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

/**
 *
 * @author Estudiante
 */
public class Note {
    
    private int IdNote;
    private String NameNote;
    private String Description;
    private int IdPerson;
    
    public Note() {
    }

    public Note(int IdNote, String NameNote, String Description, int IdPerson) {
        this.IdNote = IdNote;
        this.NameNote = NameNote;
        this.Description = Description;
        this.IdPerson = IdPerson;
    }

    public int getIdNote() {
        return IdNote;
    }

    public void setIdNote(int IdNote) {
        this.IdNote = IdNote;
    }

    public String getNameNote() {
        return NameNote;
    }

    public void setNameNote(String NameNote) {
        this.NameNote = NameNote;
    }

    public String getDescription() {
        return Description;
    }

    public void setDescription(String Description) {
        this.Description = Description;
    }

    public int getIdPerson() {
        return IdPerson;
    }

    public void setIdPerson(int IdPerson) {
        this.IdPerson = IdPerson;
    }
    
    
    
}
