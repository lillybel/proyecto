/*
 * To appnge this license header, choose License Headers in Project Properties.
 * To appnge this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Bean;
import DaoConexion.NoteDao;
import Model.Note;
import java.util.List;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.SessionScoped;

@ManagedBean
@SessionScoped
public class NoteBean {
    
    private Note note = new Note();
    private List<Note> lstNote;

    public Note getNote() {
        return note;
    }

    public void setNote(Note note) {
        this.note = note;
    }

    public List<Note> getLstNote() {
        return lstNote;
    }

    public void setLstNote(List<Note> lstNote) {
        this.lstNote = lstNote;
    }

    public void registrar() throws Exception{
        NoteDao dao;
    try{
        dao = new NoteDao();
        dao.registrar(note);
    }catch(Exception e){
        throw e;
    }
    }
     public void listar() throws Exception{
        NoteDao dao;
    try{
        dao = new NoteDao();
        lstNote = dao.listar();
    }catch(Exception e){
        throw e;
    }
    }
      public void leerID(Note app) throws Exception{
         NoteDao dao;
         Note temp;
    try{
        dao = new NoteDao();
        temp = dao.leerId(app);
        
        if(temp !=null){
            this.note = temp;
        }
    }catch(Exception e){
        throw e;
    }
    }
       public void modificar() throws Exception{
        NoteDao dao;
    try{
        dao = new NoteDao();
        dao.modificar(note);
        this.listar();
    }catch(Exception e){
        throw e;
    }
    }
       public void eliminar(Note app) throws Exception{
        NoteDao dao;
    try{
        dao = new NoteDao();
        dao.eliminar(app);
        this.listar();
    }catch(Exception e){
        throw e;
    }
    }
}