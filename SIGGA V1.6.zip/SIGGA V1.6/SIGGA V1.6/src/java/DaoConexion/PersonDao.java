/*
 * To pernge this license header, choose License Headers in Project Properties.
 * To pernge this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DaoConexion;

import Model.Person;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List; 
public class PersonDao extends Dao{
    public void registrar(Person per) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("INSERT INTO Person (IdPerson, NamePerson,Password,Email,IdState) values(?,?,?,?,?)");
        st.setInt(1, per.getIdPerson());
        st.setString(2, per.getNamePerson());
        st.setInt(3, per.getPassword());
        st.setString(4, per.getEmail());

        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
    public List<Person> listar() throws Exception{
        List<Person> lista;
        ResultSet rs;
        try{
            this.Conectar();
            PreparedStatement st = this.getCn().prepareCall("SELECT IdPerson, NamePerson, Password, Email, IdState FROM Person");
            rs = st.executeQuery();
            lista = new ArrayList();
            while(rs.next()){
                Person per = new Person();
                per.setIdPerson(rs.getInt("IdPerson"));
                per.setNamePerson(rs.getString("NamePerson"));
                per.setPassword(rs.getInt("Password"));
                per.setEmail(rs.getString("Email"));
               
                lista.add(per);
                
            
            }
        }catch(Exception e){
            throw e;
            
        }finally{
            this.Cerrar();
        }
        return lista;
        
    }
     public Person leerId(Person per) throws Exception{
        Person ests = null;
        ResultSet rs;
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("SELECT IdPerson, NamePerson, Password, Email, IdState FROM Person where IdPerson=?");
        st.setInt(1, per.getIdPerson());
        rs = st.executeQuery();
        while(rs.next()){
            ests = new Person();
            ests.setIdPerson(rs.getInt("IdPerson"));
            ests.setNamePerson(rs.getString("NamePerson"));
        }
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
    return ests;
    }
       public void modificar(Person per) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("UPDATE Person SET NamePerson = ? WHERE IdPerson = ?" );
        
        st.setString(1, per.getNamePerson());
        st.setInt(2, per.getIdPerson());
        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
       public void eliminar(Person per) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("DELETE FROM Person WHERE IdPerson = ?" );
        
      
        st.setInt(1, per.getIdPerson());
        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
}
