/*
 * To appnge this license header, choose License Headers in Project Proappties.
 * To appnge this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DaoConexion;

import Model.Note;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List; 
public class NoteDao extends Dao{
    public void registrar(Note app) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("INSERT INTO Note (IdNote, NameNote,Description,IdPerson) values(?,?,?,?)");
        st.setInt(1, app.getIdNote());
        st.setString(2, app.getNameNote());
        st.setString(3, app.getDescription());
        st.setInt(4, app.getIdPerson());
        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
    public List<Note> listar() throws Exception{
        List<Note> lista;
        ResultSet rs;
        try{
            this.Conectar();
            PreparedStatement st = this.getCn().prepareCall("SELECT IdNote, NameNote, Description, IdPerson FROM Note");
            rs = st.executeQuery();
            lista = new ArrayList();
            while(rs.next()){
                Note app = new Note();
                app.setIdNote(rs.getInt("IdNote"));
                app.setNameNote(rs.getString("NameNote"));
                app.setDescription(rs.getString("Description"));
                app.setIdPerson(rs.getInt("IdPerson"));
                lista.add(app);
                
            
            }
        }catch(Exception e){
            throw e;
            
        }finally{
            this.Cerrar();
        }
        return lista;
        
    }
     public Note leerId(Note app) throws Exception{
        Note ests = null;
        ResultSet rs;
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("SELECT IdNote, NameNote, Description, IdPerson FROM Note where IdNote=?");
        st.setInt(1, app.getIdNote());
        rs = st.executeQuery();
        while(rs.next()){
            ests = new Note();
            ests.setIdNote(rs.getInt("IdNote"));
            ests.setNameNote(rs.getString("NameNote"));
        }
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
    return ests;
    }
       public void modificar(Note app) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("UPDATE Note SET NameNote = ? WHERE IdNote = ?" );
        
        st.setString(1, app.getNameNote());
        st.setInt(2, app.getIdNote());
        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
       public void eliminar(Note app) throws Exception{
    try{
        this.Conectar();
        PreparedStatement st = this.getCn().prepareStatement("DELETE FROM Note WHERE IdNote = ?" );
        
      
        st.setInt(1, app.getIdNote());
        st.executeUpdate();
    }catch(Exception e){
        throw e;
    }finally{
        this.Cerrar();
    }
        }
}
